TRUSTSETS v1.4.9 - GOLD CORNER DETAIL UPDATE
Author: Dugahst
Ashita v4 | Final Fantasy XI
============================================================

INSTALL / UPGRADE
-----------------
1. Extract this archive into your Ashita/addons/ directory, placing
   the Lua file at: Ashita/addons/trustsets/trustsets.lua
2. Replace the existing trustsets.lua. Your custom presets are saved in
   Ashita's separate per-character settings area; do NOT delete them.
3. In-game run: /addon reload trustsets
   (or /addon load trustsets if it is not loaded).
4. Open the GUI with: /tsets or /trustsets

WHAT'S NEW IN v1.4.9
--------------------
* Reverted to the v1.4.7 GUI code and layout as requested.
* Added four glowing gold L-corner ornaments with inset gold diamonds, matching
  the Olympus Hate corner close-up. Ornaments can extend just outside the window
  edge because the draw list's clip region is expanded temporarily.
* No other GUI redesign from v1.4.8 was kept.
* No mouse interception or new game logic was added.
* Summon retry, capture, casting delay dropdown, commands and settings unchanged.

PRIOR v1.4.7 THEME
------------------
* Restyled the GUI based on the provided Olympus Wiki reference image:
  nearly black navy backgrounds, gold borders and separators, gold headings,
  soft ice-blue secondary text, and compact flat controls.
* Retained the v1.4.6 editor, footer, hidden startup, and automatic summon
  verification/retries (3 total attempts per Trust).
* Retained the 4/5/6/7-second cast delay dropdown and saved preference.
* Styling is local to the TrustSets window; it does not modify other addons.
* No experimental mouse click-interception logic has been reintroduced.
* Does not replace or delete existing character presets or their settings.

PREVIOUS v1.4.6 SUMMON RETRIES
------------------------------
* Built directly on v1.4.5, keeping the compact GUI, capture, presets,
  command aliases, cast-delay dropdown, and v1.4.1 mouse behavior.
* After sending a Trust spell, checks whether the matching Trust actually
  joined your active party before advancing to the next member.
* If no matching new party member is detected after a grace period, the
  addon retries the same Trust (up to 3 total casts: 1 initial + 2 retries).
* If all 3 attempts are unverified, the addon reports the name and advances
  to the rest of your preset instead of becoming stuck forever.
* Already-active Trusts are skipped, rather than unnecessarily recast.
* Supports FFXI party names without spaces (MihliAliapoh) and names whose
  party display omits the spell suffix (Tenzen II, some Unity Trusts).
* The existing delay dropdown remains 4, 5, 6, or 7 seconds; this is the
  MINIMUM interval between summon commands when a cast succeeds.
* A failed summon allows an 8-10 second confirmation window before retry,
  depending on your selected delay. This avoids spamming retries while
  cast animation or party update is still in progress.
* Queue progress now shows checked Trusts and current attempt count.
* No experimental mouse-click interception code was reintroduced.

GUI
---
The GUI starts HIDDEN on every addon load. Use /tsets or /trustsets
in chat to toggle it.

LEFT PANEL
  Select a saved preset, create a new preset, or capture current Trusts.
RIGHT PANEL
  Edit up to five members, save/delete presets, summon or replace.
BOTTOM
  View queue progress, stop a queue, dismiss Trusts, and set cast delay.

CHAT COMMANDS
-------------
    /tsets or /trustsets          Toggle the GUI
    /tsets open                  Show the GUI
    /tsets close                 Hide the GUI
    /tset gui                    Legacy GUI toggle
    /tset capture [NAME]         Save active Trusts to a NEW set
    /tset list                   List saved presets
    /tset show NAME              Show a preset
    /tset add NAME A, B, C       Save/update a preset (max 5)
    /tset run NAME               Summon without dismissal
    /tset replace NAME           Dismiss existing Trusts, then summon
    /tset delay [4|5|6|7]        Show/change delay between summons
    /tset status                 Show active summon queue status
    /tset stop                   Cancel remaining summons AND retries
    /tset release                Dismiss all Trusts
    /tset delete NAME            Delete a preset
    /tset status                 Show current Trust / retry status
    /tset help                   Print chat commands

COMPATIBILITY / LIMITATIONS
---------------------------
* Ashita v4 only; v3 APIs differ.
* The addon uses ordinary /ma "Trust Name" <me> and /refa all commands.
* Summon confirmation checks the active party roster; it cannot know the
  exact error message that caused a failed cast. Server restrictions such
  as combat, unavailable Trusts, party limits, and bad spell names still
  apply. When these block summoning, the addon reports the failure.
* Summon verification relies on Ashita v4 party and entity memory. If
  those APIs are unavailable while zoning/loading, the queue stops safely
  rather than issuing unverified repeated commands.
* Any alternative versions that look identical in the party list cannot
  be distinguished conclusively by this method (e.g. Shantotto vs
  Shantotto II). Check the editor if you capture an ambiguous version.
* Some Trust versions are ambiguous in the FFXI party display; verify
  alternate Trusts (such as Shantotto II) after capturing a party.
* Name-normalization fixes from v1.4 are retained, including
  MihliAliapoh -> Mihli Aliapoh.
* Based on v1.4.1, this build does not fix clicking through the GUI into
  the game world. No experimental mouse interceptors are installed.
* Lua syntax and multiple simulated Ashita behavior scenarios have been
  checked locally; v1.4.7 has NOT been tested in a running FFXI client.
